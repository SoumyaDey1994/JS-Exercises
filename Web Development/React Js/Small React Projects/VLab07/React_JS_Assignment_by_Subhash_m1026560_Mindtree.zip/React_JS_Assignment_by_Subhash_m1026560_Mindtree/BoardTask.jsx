import React from 'react';

class BoardTask extends React.Component {
	constructor(props) {
		super(props);
		this.state = {isChecked: this.props.data.done};		
		this.onChange = this.onChange.bind(this);
	}	
	onChange() {
		this.setState({isChecked: !this.state.isChecked});
	}
	
	render() {
		
		return(
			<li>
				<input type="checkbox" checked={this.state.isChecked} onChange={this.onChange} /> {this.props.data.name}		
			</li>
			
		);
	}
	
}
export default BoardTask;