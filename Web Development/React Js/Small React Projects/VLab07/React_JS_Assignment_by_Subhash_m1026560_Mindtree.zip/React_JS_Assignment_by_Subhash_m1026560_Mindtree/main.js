import React from 'react';
import ReactDom from 'react-dom';
import Board from './Board.jsx';
import BoardColumn from './BoardColumn.jsx';

ReactDom.render(<Board/>, document.getElementById('content'));