1. From command prompt enter to this folder.
2. npm install
3. npm start
4. goto browser http://localhost:8080/Noticeboard.html