var React = require('react');
var ReactDOM = require('react-dom');

var Checkbox = React.createClass({
    getInitialState() {
      return {
        checked: this.props.taskList.done,
        text: this.props.taskList.name,
        id:this.props.taskList.id,
      };
    },

    handleChange() {
        this.setState({ checked: !this.state.checked });
    },

    render: function() {
        var content = this.state.checked
          ?  <strike> {this.state.text} </strike>
          : this.state.text;

        return (
            <label id={this.state.id}>
            <input
                className = 'Checkbox'
                type = 'checkbox'
                checked={this.state.checked}
                onChange={this.handleChange} 
            />
            {content}
          </label>
        );

    }
});

module.exports = Checkbox;
