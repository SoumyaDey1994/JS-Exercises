var React = require('react');
var ReactDOM = require('react-dom');
var TaskList = require('./Task') ;


var NoticeStatus = React.createClass({
    render: function() {
        var tasks = this.props.cards;
        var dataList = tasks.map(function (task) {
            return (
                <div key={task.id}>
                    <h3>{task.status}</h3>
                    <div className = "card">
                        <div className = "title"><div className="arrow"> </div> {task.title}</div>
                        <div className = "desc">{task.description}</div>
                        <TaskList taskList={task.tasks} />
                    </div>
                 </div>
            );
        });
        return  <div className = "col-group">{dataList}</div>;
    }
});

module.exports = NoticeStatus;

