var React = require('react');
var ReactDOM = require('react-dom');

var Checkbox = React.createClass({
    getInitialState() {
      return {
        checked: this.props.taskList.done
      };
    },

    handleChange() {
        this.setState({ checked: !this.state.checked });
    },

    getTaskText() {
       if (this.state.checked) {
            return (
                <s>{this.props.taskList.name}</s>
            ); 
        }
        return (
            <span>{this.props.taskList.name}</span>
        );
    },
    render: function() {
        var taskName = this.getTaskText();
        return (
            <label>
                <input
                    className = 'Checkbox'
                    type = 'checkbox'
                    id = {this.props.taskList.id}
                    value = {this.props.taskList.name}
                    checked = {this.state.checked}
                    onChange = {this.handleChange}
                />
                {taskName}
            </label>
        );

    }
});

module.exports = Checkbox;
