var React = require('react');
var ReactDOM = require('react-dom');
var TaskList = require('./Task') ;


var NoticeBoard = React.createClass({
    render: function() {
        var tasks = this.props.cards;
        var toDoTasks = [];
        var inProgressTasks = [];
        var doneTasks = [];
        tasks.forEach(function(task, index) {
            switch (task.status) {
                case 'todo':
                    toDoTasks.push(task);
                    break;
                case 'in-progress':
                    inProgressTasks.push(task);
                    break;
                case 'completed':
                    doneTasks.push(task)
                    break;
            }
        });
        var toDoTasksList = this.getTaskHtml(toDoTasks);
        var inProgressTasksList = this.getTaskHtml(inProgressTasks);
        var doneTasksList = this.getTaskHtml(doneTasks);

        return  (
            <div className="container">
                <div className="row">
                    <div className="col-md-4">
                        <h2>To Do</h2>
                        {toDoTasksList}
                    </div>
                    <div className="col-md-4">
                        <h2>In Progress</h2>
                        {inProgressTasksList}
                    </div>
                    <div className="col-md-4">
                        <h2>Completed</h2>
                        {doneTasksList}
                    </div>
                </div>
            </div>
        );
    },
    getTaskHtml: function(tasks) {
        var taskHtml = tasks.map(function (task) {
            return (
                <div key={task.id} className="task-group">
                    <p className="primary">{task.title}</p>
                    <p className="secondary">{task.description}</p>
                    <TaskList taskList={task.tasks} />
                 </div>
            );
        });
        return taskHtml;
    }
});

module.exports = NoticeBoard;

