var React = require('react');
var ReactDOM = require('react-dom');

var Checkbox = React.createClass({
    getInitialState() {
      return {
        checked: this.props.taskList.done
      };
    },

    handleChange() {
        this.setState({ checked: !this.state.checked });
    },

    render: function() {
        return (
            <label className="label">
            <input
                className = 'Checkbox'
                type = 'checkbox'
                id={this.props.taskList.id}
                value = {this.props.taskList.name}
                checked={this.state.checked}
                onChange={this.handleChange} checked={this.state.checked}
            />
            <span>{this.props.taskList.name}</span>
          </label>
        );

    }
});

module.exports = Checkbox;
