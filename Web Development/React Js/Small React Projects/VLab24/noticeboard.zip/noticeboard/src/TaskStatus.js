import React from 'react';
import ReactDom from 'react-dom';



class TaskStatus extends React.Component{
	constructor(props){
    super(props);
    
  }
  
  render(){
	  
	       
		   return (
                <ul>
                {
                  this.props.tasks.map(function(item) {
                    return (
					<div className="checkbox-tasks" key={item.id}>
					<input type="checkbox" value={item.done} checked={item.done}/>
					<label>{item.name}</label>
					</div>
					)
                  })
                 }
                </ul>
              ) 
		  
	  
  }
}

TaskStatus.propTypes = {
  id: React.PropTypes.number,
  name: React.PropTypes.string,
  done		 : React.PropTypes.boolean
};

export default TaskStatus ;