var React = require('react');
var ReactDOM = require('react-dom');

var Checkbox = React.createClass({
    getInitialState() {
      return {
        checked: this.props.taskList.done,
        text: this.props.taskList.name,
      };
    },

    handleChange() {
        this.setState({ checked: !this.state.checked });
    },

    render: function() {
        var content = this.state.checked
          ?  <strike> {this.state.text} </strike>
          : this.state.text;

        return (
            <label id={this.props.taskList.id}>
            <input
                className = 'Checkbox'
                type = 'checkbox'
                id={this.props.taskList.id}
                value = {this.props.taskList.name}
                checked={this.state.checked}
                onChange={this.handleChange} checked={this.state.checked}
            />
            {content}
          </label>
        );

    }
});

module.exports = Checkbox;
