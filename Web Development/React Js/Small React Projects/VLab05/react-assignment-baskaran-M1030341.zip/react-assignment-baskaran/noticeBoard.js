var React = require('react');
var ReactDOM = require('react-dom');
var TaskList = require('./Task') ;


var status = React.createClass({
    render: function() {
        var tasks = this.props.cards;
        var dataList = tasks.map(function (task) {
            return (
                <div key={task.id} className="col-md-4">
                    <h3 className="status">{task.status}</h3>
                    <div className="contents">
                    <span className="title">{task.title}</span>
                    <p className="description">{task.description}</p>
                    <TaskList taskList={task.tasks} />
                 </div>
                    </div>
            );
        });
        return  <div className="container"><div className="row">{dataList}</div></div>;
    }
});

module.exports = status;

