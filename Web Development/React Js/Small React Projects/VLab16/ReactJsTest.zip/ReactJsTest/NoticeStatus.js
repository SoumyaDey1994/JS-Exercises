var React = require('react');
var ReactDOM = require('react-dom');
var TaskList = require('./Task') ;


var NoticeStatus = React.createClass({
    render: function() {
        var tasks = this.props.cards;
        var dataList = tasks.map(function (task) {
            return (
                <div  className="unit" key={task.id}>
                    <h1>{task.status}</h1>
                    {task.title}
                    {task.description}
                    <TaskList taskList={task.tasks} />
                 </div>
            );
        });
        return  <div className="container" >{dataList}</div>;
    }
});

module.exports = NoticeStatus;

