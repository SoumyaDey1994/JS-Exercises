var React = require('react');
var ReactDOM = require('react-dom');
var Checkbox = require('./Checkbox') ;


var Task = React.createClass({

    render: function() {
        var tasks = this.props.taskList;
        var list = tasks.map(function (task) {
            return (
                <div className="element-input" key={task.id}>
                    <Checkbox taskList = {task} />
                 </div>
            );
        });
        return  <div className="board">{list}</div>;
    }
});

module.exports = Task;
