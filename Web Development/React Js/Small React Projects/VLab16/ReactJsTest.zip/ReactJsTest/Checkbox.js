var React = require('react');
var ReactDOM = require('react-dom');

var getcheckbox = React.createClass({
    getInitialState() {
      return {
        checked: this.props.taskList.done
      };
    },
    handleChange() {
        console.log('Changing');
        this.setState({ checked: !this.state.checked });
    },

    render: function() {
        return (
            <label>
            <input
                className = 'elementcheck'
                type = 'checkbox'
                id={this.props.taskList.id}
                value = {this.props.taskList.name}
                checked={this.state.checked}
                onChange={this.handleChange} checked={this.state.checked}
            />
            {this.props.taskList.name}
          </label>
        );

    }
});
module.exports = getcheckbox;
