import React from 'react';
class Task extends React.Component {
   
   render() {
      return (
            <div className="main">
         		<h2>
                 {(this.props.list.status == 'todo') ? "TO DO": ''}
                 {(this.props.list.status == 'in-progress') ? "In Progress": ''}
                 {(this.props.list.status == 'done') ? "Done": ''}
               </h2>

               <div id = {this.props.list.status}>
                  <i className="fa">&#xf0da;</i>
            		<h4>{this.props.list.title}</h4>
            		<span>{this.props.list.description}</span>
                  <hr className="dash"/>
                  <div>
                     {this.props.list.tasks.map((name, i) => <Listing key = {i} list = {name} />)}
                  </div>
               </div>

            </div>	
      );
   }
}

class Listing extends React.Component{
	render(){
		return(
         <div>
			    <input type="checkbox" defaultChecked = {this.props.list.done} />
            {this.props.list.name}
         </div>
			);
	}
}
export default Task;