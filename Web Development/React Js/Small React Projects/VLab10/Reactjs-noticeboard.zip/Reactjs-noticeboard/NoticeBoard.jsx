import React from 'react';
import Task from './Task.jsx'

class NoticeBoard extends React.Component {
   render() {
      return (
      	<div className="noticeboard">
      	  {this.props.cards.map((task, i) => <Task key = {i} list = {task} />)}
        </div>
      );
   }
}

export default NoticeBoard;