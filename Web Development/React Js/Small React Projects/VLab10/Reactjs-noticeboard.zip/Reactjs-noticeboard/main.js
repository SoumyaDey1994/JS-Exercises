import React from 'react';
import ReactDOM from 'react-dom';

import List from './List.jsx';

ReactDOM.render(<List />, document.getElementById('app'));
