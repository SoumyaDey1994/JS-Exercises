var React = require('react');
var ReactDOM = require('react-dom');
var Todo = require('./components/Todocomp');
var InProgress = require('./components/InProgresscomp');
var Done = require('./components/Donecomp');
var Header = require('./components/Headercomp');

class Indexcomponent extends React.Component {
    render() {
        return (
            <div>
                <Header header="My First React APP"/>
                <Todo heading="Write some code"/>
                <InProgress heading="Read the project requirement"/>
                <Done heading="Create Use Cases"/>
            </div>
        )

    }
}

ReactDOM.render(
    <Indexcomponent/>,
    document.getElementById('app')
);
