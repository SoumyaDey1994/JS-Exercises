var React = require('react');
var AppActions = require('../actions/AppActions');
var AppStore = require('../stores/AppStore');
var AppConstants = require('../constants/AppConstants');

function getappdatastate(){
	return {
		todolist:AppStore.getTododata()
	}
}
class Todo extends React.Component {
     constructor(props) {
    super(props);
    this.state =  getappdatastate();
  }

    render() {
        console.log(this.state);
        const {todolist}=this.state;
        return (

             <div className = "container" style={AppConstants.cardsize}>
                <h4>To do </h4>
                <div className = "cardlayout">
                    <div>
                        <p style={AppConstants.todostepssize}><b>{this.props.heading}</b><br/>
                            Code based on current CRs</p>
                        <hr/>
                        <form style={AppConstants.todostepssize} action="">
                        <input type="checkbox" value={todolist[0].work}/>
                            <span>{todolist[0].work}</span>
                        <br/>
                        <input type="checkbox" value={todolist[0].work}/>
                            <span>{todolist[1].work}</span>
                        <br/>
                        <input type="checkbox" value={todolist[0].work}/>
                            <span>{todolist[2].work}</span>
                        <br/>
                        </form>
                    </div>
                </div>
            </div>
            
        )
    }
}

module.exports = Todo;