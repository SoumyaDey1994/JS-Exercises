var AppDispatcher = require('../dispatcher/AppDispatcher');
var AppConstants = require('../constants/AppConstants');

var AppActions = {
    createtodolist:function(work){
        AppDispatcher.handleViewAction({
        actionType:"createlist",
        work:work
    });
    }	
}

module.exports = AppActions;