var React = require('react');
var AppActions = require('../actions/AppActions');
var AppStore = require('../stores/AppStore');
var AppConstants = require('../constants/AppConstants');

class InProgress extends React.Component {
    render() {
        return (
            <div className = "container" style={AppConstants.cardsize}>
                <h4>In Progress </h4>
                <div className = "cardlayout">
                    <div>
                        <p style={AppConstants.todostepssize}><b>{this.props.heading}</b><br/>
                            Should read required document</p>
                        <hr/>
                        <form style={AppConstants.todostepssize} action="">
                            <input type="checkbox"/>Revise HLD<br/>
                            <input type="checkbox"/>Revise Initiate<br/>
                            <input type="checkbox"/>Revise Apply<br/>
                        </form>
                    </div>
                </div>
            </div>
        )
    }
}

module.exports = InProgress;