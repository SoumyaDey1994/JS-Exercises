var React = require('react');
var AppActions = require('../actions/AppActions');
var AppStore = require('../stores/AppStore');
var AppConstants = require('../constants/AppConstants');

class Todo extends React.Component {
    render() {
        return (
            <div className="container-empty" style={AppConstants.cardsize}>
                <h4>Done </h4>
                <div className = "cardlayout">
                    <div>
                        <p style={AppConstants.todostepssize}><b>{this.props.heading}</b><br/>
                            Should understand requirement</p>
                        <hr/>
                        <form style={AppConstants.todostepssize} action="">
                            <input type="checkbox"/>Revise architecture<br/>
                        </form>
                    </div>
                </div>

            </div >
        )
    }
}

module.exports = Todo;