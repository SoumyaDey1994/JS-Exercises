module.exports = {
    cardsize : {
    width: '30%',
    float: 'left'
},
todostepssize : {
    fontSize: 'smaller'
} 
};