var React = require('react');
var AppActions = require('../actions/AppActions');
var AppStore = require('../stores/AppStore');
var AppConstants = require('../constants/AppConstants');

class Header extends React.Component {
    render() {
        return (
            <div className = "header">
                <p className="headertitle"><b>Welcome To {this.props.header}</b></p>
            </div>
        )
    }
}

module.exports = Header;