import React from 'react';
import ReactDom from 'react-dom';
import TaskBoard from './TaskBoard';

let cardsList = [
            {
                id: 1,
                title: "Write some code",
                description: "Code based on the current CRs",
                status: "todo",
                tasks: [
                        {
                            id: 1,
                            name: "Call Ravi",
                            done: true
                        },
                        {
                            id: 2,
                            name: "Reply to the emails",
                            done: false
                        },
                        {
                            id: 3,
                            name: "Read the bug reports",
                            done: true
                        }
                    ]
            },
            {
                id: 2,
                title: "Read the project requirement",
                description: "Should read the whole req doc",
                status: "in-progress",
                tasks: [{
                            id: 1,
                            name: "Revise HLD",
                            done: false
                        }]
            },
            {
                id: 4,
                title: "Analyse the code",
                description: "Modified code",
                status: "completed",
                tasks: [
                        {
                            id: 1,
                            name: "Fix changes",
                            done: true
                        },
                        {
                            id: 2,
                            name: "Send status",
                            done: false
                        },
                        {
                            id: 3,
                            name: "Prepare reports",
                            done: false
                        }
                    ]
            },
            
   ];


ReactDom.render(<TaskBoard cards={cardsList} />, document.getElementById('content'));
