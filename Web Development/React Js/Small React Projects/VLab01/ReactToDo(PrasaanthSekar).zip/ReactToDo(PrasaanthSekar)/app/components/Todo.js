var React = require('react');

const divWidth = {
    width: '30%',
    float: 'left'
};

const smallText = {
    fontSize: 'smaller'
};

class Todo extends React.Component {
    render() {
        return (
            <div className = "container" style={divWidth}>
                <h4>To do </h4>
                <div className = "card">
                    <div>
                        <p style={smallText}><b>{this.props.heading}</b><br/>
                            Code based on current CRs</p>
                        <hr/>
                        <form style={smallText} action="">
                            <input type="checkbox" name="vehicle" value="Bike"/>Call Ravi<br/>
                            <input type="checkbox" name="vehicle" value="Car"/>Reply to the emails<br/>
                            <input type="checkbox" name="vehicle" value="Car"/>Read the bug reports<br/>
                        </form>
                    </div>
                </div>
            </div>
        )
    }
}

module.exports = Todo;