var React = require('react');

const divWidth = {
    width: '30%',
    float: 'left'
};

const smallText = {
    fontSize: 'smaller'
};

class InProgress extends React.Component {
    render() {
        return (
            <div className = "container" style={divWidth}>
                <h4>In Progress </h4>
                <div className = "card">
                    <div>
                        <p style={smallText}><b>{this.props.heading}</b><br/>
                            Should read the whole required document</p>
                        <hr/>
                        <form style={smallText} action="">
                            <input type="checkbox" name="vehicle" value="Bike"/>Revise HLD<br/>
                        </form>
                    </div>
                </div>
            </div>
        )
    }
}

module.exports = InProgress;