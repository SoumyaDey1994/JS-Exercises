var React = require('react');

const divWidth = {
    width: '30%',
    float: 'left'
};

const smallText = {
    fontSize: 'smaller'
};

class Todo extends React.Component {
    render() {
        return (
            <div className="container-empty" style={divWidth}>
                <h4>Done </h4>

            </div >
        )
    }
}

module.exports = Todo;