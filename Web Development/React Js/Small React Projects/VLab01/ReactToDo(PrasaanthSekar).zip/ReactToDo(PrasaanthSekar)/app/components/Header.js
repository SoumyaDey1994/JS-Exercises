var React = require('react');

class Header extends React.Component {
    render() {
        return (
            <div className = "header">
                <p className="header-text"><b>{this.props.header}</b></p>
            </div>
        )
    }
}

module.exports = Header;