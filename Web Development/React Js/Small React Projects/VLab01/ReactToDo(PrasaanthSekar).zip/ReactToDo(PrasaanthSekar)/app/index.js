var React = require('react');
var ReactDOM = require('react-dom');
var Todo = require('./components/Todo');
var InProgress = require('./components/InProgress');
var Done = require('./components/Done');
var Header = require('./components/Header');

class MainComponent extends React.Component {
    render() {
        return (
            <div>
                <Header header="TODO REACT APP"/>
                <Todo heading="Write some code"/>
                <InProgress heading="Read the project requirement"/>
                <Done/>
            </div>
        )

    }
}

ReactDOM.render(
    <MainComponent/>,
    document.getElementById('app')
);