//import React, {Component,PropTypes} from 'react';

import React from 'react';
import ReactDom from 'react-dom';
import TaskList from './TaskList';


class Noticeboard extends React.Component{
  constructor(props){
    super(props);
    
    this.state = {
     
    };
  }

	render(){
		
		return (
                <div className = "cards">
                {
                  this.props.cards.map(function(item) {
				  return(
				  
				  <div key={item.id} className= "items-status vdivide">
					<div className="status">
					{item.status}
					</div>
					<div className="items-status-info">
						<div className="status-info">
							<div className="title">	{item.title}</div>
							<div className="desc">	{item.description}</div>
						</div>
						<div className="tasks-list">
							<TaskList tasks = {item.tasks}/>
						</div>
					</div>
					
				  </div>
				  
                  )
                 })
				 
				}
                </div>
              ) 
	}
}


Noticeboard.propTypes = {
  id: React.PropTypes.number,
  title: React.PropTypes.string,
  description: React.PropTypes.string,
  status     : React.PropTypes.string,
  tasks		 : React.PropTypes.object
};

export default  Noticeboard ;
