import React from 'react';
import ReactDom from 'react-dom';
import NoticeBoard from './reactproj-status';
let cardsList = [
			{
			    id: 1,
			    title: "Write some code",
			    description: "Code based on the current CRs",
			    status: "todo",
			    tasks: [
			            {
			                id: 1,
			                name: "Call Ravi",
			                done: true
			            },
			            {
			                id: 2,
			                name: "Reply to the emails",
			                done: false
			            },
			            {
			                id: 3,
			                name: "Read the bug reports",
			                done: false
			            }
			        ]
			},
            {
                id: 2,
                title: "Read the proj reqt",
                description: "should read the whole reqt doc",
                status: "in-progress",
                tasks: [{
                            id: 1,
                            name: "revise HLD",
                            done: false
                        }]
            }
            
   ];
ReactDom.render(
    <NoticeBoard cards={cardsList} />,
    document.getElementById('mainContent'));
