var React = require('react');
var AppActions = require('../actions/AppActions.jsx');
var AppStore = require('../stores/AppStore.jsx');
var Todo = require('./Todo.jsx');

function getAppState(){
	return {
		todos:AppStore.getAllTodo()
	}
}

var App = React.createClass({
	// constructor(){
	// 	super();
	// 	console.log("this.state",this.state)
	// },
	getInitialState: function(){
		return getAppState()
	
	},
	componentWillMount:function(){
		// this.setState({
		// 	todos:AppStore.getAllTodo()
		// })
	},
	componentDidMount: function(){
		AppStore.addChangeListener(this._onChange);
	},

	componentUnmount: function(){
		AppStore.removeChangeListener(this._onChange);
	},
	createTodo:function(){
		AppActions.createTodo(Date.now())
	},

	render: function(){
		const {todos}=this.state;
		const TodoComponents=todos.map((todo)=>{
			return <Todo key={todo.id} {...todo}/>
		})
		return(
			<div>
				<h1>Todos</h1>
				<button onClick={this.createTodo.bind(this)}>Create Todo</button>
				<input type='text' />
				<ul>
					{TodoComponents}
				</ul>
			</div>
		);
	},

	// Update view state when change is received
	_onChange: function(){
		this.setState(getAppState());
		console.log("Changed");
	}
});

module.exports = App;