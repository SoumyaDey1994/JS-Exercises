var AppDispatcher = require('../dispatcher/AppDispatcher.jsx');
var AppConstants = require('../constants/AppConstants');

var AppActions = {
	createTodo:function(text){
        AppDispatcher.handleViewAction({
            actionType:"CREATE_TODO",
            text:text
        })
    }
}

module.exports = AppActions;