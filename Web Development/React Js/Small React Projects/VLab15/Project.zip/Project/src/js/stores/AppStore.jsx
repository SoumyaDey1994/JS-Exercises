var AppDispatcher = require('../dispatcher/AppDispatcher.jsx');
var AppConstants = require('../constants/AppConstants');

var EventEmitter = require('events').EventEmitter;
var assign = require('object-assign');
var AppAPI = require('../utils/AppAPI.js');

var CHANGE_EVENT = 'change';

var _items = [{
	id:123,
	text:"Wash Clothes",
	complete:false
}]; // am: store any state info.

var AppStore = assign({}, EventEmitter.prototype, {
	emitChange: function(){
		this.emit(CHANGE_EVENT);
	},
	addChangeListener: function(callback){
		this.on('change', callback);
	},
	removeChangeListener: function(callback){
		this.removeListener('change', callback);
	},
	createTodo:function(text){
		const id=Date.now();
		_items.push({
			id:this.id,
			text:text,
			complete:false
		});
		this.emit('change');
	},
	getAllTodo:function(){
		return _items;
	}
});

AppDispatcher.register(function(payload){
	console.log("payload",payload)
	var action = payload.action;
	console.log("action",action)

	switch(action.actionType){
		case "CREATE_TODO":{
			AppStore.createTodo(action.text);
		}
	}

	return true;
});
window.AppDispatcher=AppDispatcher;
window.AppStore=AppStore;
module.exports = AppStore;