var React = require('react');
var ReactDOM = require('react-dom');
var TaskList = require('./Task') ;


var NoticeStatus = React.createClass({
    render: function() {
        var tasks = this.props.cards;
        var dataList = tasks.map(function (task) {
            return (
                <div className="col"key={task.id}>
                    <h1>{task.status}</h1>
                    <div className="col-c"><p className="primary">{task.title}</p>
                    <p className="secon">{task.description}</p>
                    <TaskList taskList={task.tasks} />
                 </div></div>
            );
        });
        return  <div>{dataList}</div>;
    }
});

module.exports = NoticeStatus;

